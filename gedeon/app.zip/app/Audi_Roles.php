<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Audi_Roles extends Model
{
    protected $table = 'audi_roles';
}
