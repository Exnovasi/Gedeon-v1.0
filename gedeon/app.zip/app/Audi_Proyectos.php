<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Audi_Proyectos extends Model
{
    protected $table = 'audi_proyectos';
}
