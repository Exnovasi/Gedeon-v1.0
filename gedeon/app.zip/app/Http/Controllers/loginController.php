<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Mail;
use App\Http\Requests\LoginForm;
use User;

class loginController extends Controller
{
    public function check(){
    	if(Auth::guest()){
            $message = ['error' => 'guest'];
            return $message;
    	}
    	else{
            $session = ['session' => 'Ok'];
            return $session;
    	}
    }
    public function login(LoginForm $request){
        $user = $request->input('user');
        $password = $request->input('password');
        if (Auth::attempt(['name' => $user, 'password' => $password])){
            if (Auth::user()->enabled == 1) {
                $user_name = ['name'=> User::where('name', '=', $user)->pluck('name')];
                return $user_name;
            }
            else{
                return ['error' => 'Su cuenta no esta activada'];
            }
        }
        else{
            return ['error' => 'El email o la Contraseña no son correctos'];
        }
    }
}
