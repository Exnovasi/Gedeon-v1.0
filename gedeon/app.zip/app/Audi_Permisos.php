<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Audi_Permisos extends Model
{
    protected $table = 'audi_permisos';
}
