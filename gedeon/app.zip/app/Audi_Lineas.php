<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Audi_Lineas extends Model
{
    protected $table = 'audi_lineas';
}
