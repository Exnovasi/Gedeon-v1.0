<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Audi_Users_roles extends Model
{
    protected $table = 'audi_users_roles';
}
