<!DOCTYPE html>
<html lang="es" class="theme1" ng-app="Gedeon">
<head>
    <title>Gedeón</title>
    <!-- <base href="/Gedeon/public/"> -->
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="img/faviconGedeon.ico">
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <script src="js/vendor.js"></script>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport">
    <script src="js/app.js"></script>
</head>
<body>
    <div  ng-view ></div>
</body>
<script type="text/javascript">

</script>